# Portfolio Website

This project is a simple portfolio-based website that showcases various projects and provides information about the individual behind the portfolio.

## Features

- Main entry point: `index.html`
- Additional pages: `about.html`, `contact.html`
- Responsive design with CSS styles
- JavaScript functionality for interactive elements

## Setup Instructions

1. Clone the repository:
   ```
   git clone <repository-url>
   ```

2. Navigate to the project directory:
   ```
   cd portfolio-website
   ```

3. Open `index.html` in your web browser to view the website.

4. Customize the content in the HTML files and styles in the CSS files as needed.

## Technologies Used

- HTML
- CSS
- JavaScript

## License

This project is licensed under the MIT License.